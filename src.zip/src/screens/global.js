export default {
    FIREBASE: {
        config: {
            apiKey: "AIzaSyCAvSdtSwI5e6GvqxfsMISwuCxH0lIrx3w",
            authDomain: "controlevendas-257fc.firebaseapp.com",
            databaseURL: "https://controlevendas-257fc.firebaseio.com",
            projectId: "controlevendas-257fc",
            storageBucket: "controlevendas-257fc.appspot.com",
            messagingSenderId: "373568123697"
          },
        collection: "vendas"
        
    }
}